[scikit-image Code of Conduct](doc/source/conduct/code_of_conduct.md)
