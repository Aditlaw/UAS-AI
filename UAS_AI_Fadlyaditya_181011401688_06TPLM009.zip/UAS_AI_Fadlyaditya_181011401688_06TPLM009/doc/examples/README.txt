.. _examples_gallery:

General examples
-------------------

General-purpose and introductory examples for scikit-image.

The `narrative documentation <../user_guide.html>`_ introduces
conventions and basic image manipulations.

