Longer examples and demonstrations
----------------------------------
