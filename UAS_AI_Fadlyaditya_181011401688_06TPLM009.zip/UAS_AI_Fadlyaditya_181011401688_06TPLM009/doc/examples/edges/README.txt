Edges and lines
---------------
