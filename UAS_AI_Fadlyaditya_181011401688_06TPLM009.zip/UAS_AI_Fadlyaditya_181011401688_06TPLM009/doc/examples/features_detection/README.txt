Detection of features and objects
---------------------------------
