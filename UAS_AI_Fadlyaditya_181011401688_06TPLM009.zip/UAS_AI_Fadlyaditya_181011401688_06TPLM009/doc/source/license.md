License
=======

```{literalinclude} ../../LICENSE.txt
```
